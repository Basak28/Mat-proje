
import { useState } from "react";

export default function App() {
  const [a, setA] = useState(2);
  const [b, setB] = useState(3);
  const [p, setP] = useState(17);
  const [points, setPoints] = useState([]);

  function calculatePoints() {
    const pts = [];
    for (let x = 0; x < p; x++) {
      const rhs = (x ** 3 + a * x + b) % p;
      for (let y = 0; y < p; y++) {
        if ((y * y) % p === rhs) {
          pts.push({ x, y });
        }
      }
    }
    setPoints(pts);
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Eliptik Eğri Nokta Hesaplayıcı</h1>
      <div style={{ display: 'flex', gap: 10 }}>
        <div>
          <label>a: </label>
          <input type="number" value={a} onChange={(e) => setA(+e.target.value)} />
        </div>
        <div>
          <label>b: </label>
          <input type="number" value={b} onChange={(e) => setB(+e.target.value)} />
        </div>
        <div>
          <label>mod p: </label>
          <input type="number" value={p} onChange={(e) => setP(+e.target.value)} />
        </div>
      </div>
      <button onClick={calculatePoints} style={{ marginTop: 10 }}>Noktaları Hesapla</button>
      <div style={{ marginTop: 20 }}>
        <h2>Noktalar:</h2>
        <ul>
          {points.map((pt, idx) => (
            <li key={idx}>(x: {pt.x}, y: {pt.y})</li>
          ))}
        </ul>
      </div>
    </div>
  );
}
